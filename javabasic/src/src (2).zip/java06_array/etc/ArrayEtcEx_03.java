package java06_array.etc;

import java.util.Arrays;

public class ArrayEtcEx_03 {
	public static void main(String[] args) {
		//����, Sorting
		
		//Swap, ����
		
		int num1=11;
		int num2=22;
		int temp;
		
		System.out.println(num1);
		System.out.println(num2);
		
		temp = num2;
		num2 = num1;
		num1 = temp;
		
		System.out.println(num1);
		System.out.println(num2);
		
		
	}
}
