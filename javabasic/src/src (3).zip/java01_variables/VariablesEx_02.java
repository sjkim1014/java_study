package java01_variables;

public class VariablesEx_02 {
	public static void main(String[] args) {
		char ch;
		ch = 'A';
		
		System.out.println(ch);
		
		char ch2 = '��';
		
		System.out.println(ch2);
		
		ch2 = '5';
		
		System.out.println(ch2);
		
		char ch3 = 65;
		
		System.out.println(ch3);
		
		char ch4 = 44032;
		
		System.out.println(ch4);
		
	}
}
