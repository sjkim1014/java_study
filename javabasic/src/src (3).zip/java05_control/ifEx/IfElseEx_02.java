package java05_control.ifEx;

import java.util.Scanner;

public class IfElseEx_02 {
	public static void main(String[] args) {
		int num=7;
		
		if(num%2==0) {
			System.out.println(num+"�� ¦��");
		}else {
			System.out.println(num+"�� Ȧ��");
		}
	}
}
