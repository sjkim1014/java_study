package java05_control.whileEx;

public class WhileEx_02 {
	public static void main(String[] args) {
		//1.hello 6�� ����ϱ�
		//2. 5,4,3,2,1,0���� ����ϱ�
		
		
		int i=0;
		while(i<6) {
			System.out.println("hello");
			i++;
		}
		System.out.println("-------");
		int j=5;
		while(j>=0) {
			System.out.println(j);
			j--;
		}
		
		
	}
}
