package java01_variables;

public class VariablesEx_04 {
	public static void main(String[] args) {
		//�Ǽ��� ������ Ÿ��
		//Floating Point Number
		//float(4B), double(8B)
		
		System.out.println(123);
		System.out.println(123.0); //�Ǽ��� double
		System.out.println(123.0f);	//�Ǽ��� float
		
		float f = 3.14f;
		System.out.println(f);
		
		double d = 3.14;
		System.out.println(d);
		
		
	}
}
