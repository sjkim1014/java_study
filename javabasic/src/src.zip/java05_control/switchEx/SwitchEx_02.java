package java05_control.switchEx;

public class SwitchEx_02 {
	public static void main(String[] args) {
		
		char ch='q';
		
		switch(ch) {
		case 'Q':
			System.out.println("�빮�� ť");
			break;
		
		case 'q':
			System.out.println("�ҹ��� ť");
			break;
		
		case 'a':
			System.out.println("����");
			break;
		
		case 'b':
			System.out.println("��");
			break;
		}
		
	}
}
