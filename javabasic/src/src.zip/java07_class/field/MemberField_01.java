package java07_class.field;

public class MemberField_01 {
	//�ν��Ͻ� ����
	private int num=111;
	
	//getter
	public int getNum() {
		return num;
	}
	//setter
	public void setNum(int num) {
		this.num = num;
	}
	
	
}
