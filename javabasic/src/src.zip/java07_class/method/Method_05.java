package java07_class.method;

public class Method_05 {	
	public void test01(int num) {
		num = 20;
	}
	public void test02(int[] arr) {
		arr[1] = 900;
	}
	public int test03() {
		int num = 10;
		return num;
	}
	public int[] test04() {
		int[] arr=new int[3];
		return arr;
	}
	
	
}
