package java09_abstract.interfaceEx;

public class ClassTest implements InterfaceTest{

	@Override
	public void out() {
		// TODO Auto-generated method stub
		System.out.println(NUM);
		System.out.println(MAX);
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}
	
}
