package java09_abstract.quiz;

public interface Fare {
	int FEE = 3;
	public void calc(int distance);
}
